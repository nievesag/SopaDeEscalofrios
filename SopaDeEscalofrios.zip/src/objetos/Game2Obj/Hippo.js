import Obstacle from '../Game2Obj/Obstacle.js';
export default class Hippo extends Obstacle{
    constructor(scene){ // Ponerle tambien obsGen aqui.
        super(scene, 'hippo');
    }
}