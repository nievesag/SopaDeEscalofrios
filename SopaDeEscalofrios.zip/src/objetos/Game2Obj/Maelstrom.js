import Obstacle from '../Game2Obj/Obstacle.js';
export default class Maelstrom extends Obstacle{
    constructor(scene){ // Ponerle tambien obsGen aqui.
        super(scene, 'maelstrom');
    }
}