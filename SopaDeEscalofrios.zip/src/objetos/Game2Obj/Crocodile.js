import Obstacle from '../Game2Obj/Obstacle.js';
export default class Crocodile extends Obstacle{
    constructor(scene){ 
        super(scene, 'crocodile');
    }
}