<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="tileset_duat" tilewidth="32" tileheight="32" spacing="1" margin="1" tilecount="16" columns="4">
 <image source="tileset_duat.png" width="133" height="133"/>
</tileset>
